package com.example.assigngauri;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssigngauriApplication {

	public static void main(String[] args) {
		SpringApplication.run(AssigngauriApplication.class, args);
	}

}
