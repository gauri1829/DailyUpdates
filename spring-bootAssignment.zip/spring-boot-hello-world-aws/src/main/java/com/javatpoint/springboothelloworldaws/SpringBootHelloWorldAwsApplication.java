package com.javatpoint.springboothelloworldaws;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootHelloWorldAwsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootHelloWorldAwsApplication.class, args);
	}

}
