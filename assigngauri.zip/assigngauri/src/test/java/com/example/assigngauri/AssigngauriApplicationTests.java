package com.example.assigngauri;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssigngauriApplicationTests {

	@Test
	void contextLoads() {
	}

}
